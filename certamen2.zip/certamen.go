package main

import (
	"fmt"
	_"os"
	_"strconv"
	_"encoding/csv"
	"math/rand"
	"sync"
	"time"
)

type proceso struct {
	ID              string
	State           string 
	ProgramCounter  int
}

var (
	lista_ready     = make(chan *proceso, 10)
	lista_bloqueados   = make(chan *proceso, 10)
	cpu            = make(chan *proceso, 1)
	mu             sync.Mutex
)

func dispatcher(m int, P float64) {
	for {
		// Obtener el siguiente proceso de la cola "Listo"
		select {
		case proceso := <-lista_ready:
			// Guardar estado
			fmt.Printf("\nGuardando estado de proceso %s\n", proceso.ID)
			proceso.ProgramCounter += m // Simular instrucciones ejecutadas
			
			if rand.Float64() < P { 		// probabilidad de que el proceso sea bloqueado
				proceso.State = "Bloqueado"
				fmt.Printf("\nProceso %s bloqueado. Enviando a la cola de bloqueados.\n", proceso.ID)
				lista_bloqueados <- proceso
			} else {
				fmt.Printf("Proceso %s permanece listo.\n", proceso.ID)
				proceso.State = "Listo"
				lista_ready <- proceso
			}
			
			// Cargar el siguiente proceso en CPU
			select {
			case nextproceso := <-lista_ready:
				fmt.Printf("\nCargando proceso %s en CPU.\n", nextproceso.ID)
				nextproceso.State = "Ejecutando"
				cpu <- nextproceso
			}
		}
	}
}

func procesoExecution() {
	for {
		select {
		case proceso := <-cpu:
			fmt.Printf("\nEjecutando proceso %s\n", proceso.ID)
			time.Sleep(time.Second) // Simular ejecución
			fmt.Printf("\nProceso %s completado o requiere reprogramación.\n", proceso.ID)
		}
	}
}

func generarProcesos(n int) {
	for i := 0; i < n; i++ {
		proceso := &proceso{
			ID:             fmt.Sprintf("P%d", i+1),
			State:          "Listo",
			ProgramCounter: 0,
		}
		lista_ready <- proceso
		fmt.Printf("\nProceso %s generado y enviado a la cola de Listo.\n", proceso.ID)
	}
}

/*
func leerOrganizacion(archivo string, separador rune) ([][]string, error) {
	file, err := os.Open(archivo)
	if err != nil {
		return nil, err
	}
	defer file.Close()

	reader := csv.NewReader(file)
	reader.Comma = separador

	table, err := reader.ReadAll()
	if err != nil {
		return nil, err
	}

	return table, nil
}
*/

func main() {
	//ver el orden de ejecucion
	/*
	delimiter := '\t'	//separacion por tabulación
	orden_ejecucion, err := leerOrganizacion("./organizacion.txt", delimiter)
	if err != nil {
		fmt.Printf("Error al leer el archivo")
		return
	}

	fmt.Println("Contenido de la tabla:")
	for i, fila := range orden_ejecucion {
		fmt.Printf("%v\n", fila)
		_ = i
	}
	*/
	//args := os.Args

	procesos := 5
	probabilidad_bloqueo := 0.5	//P,err := strconv.Atoi(args[2])
	/*
	if err != nil {
        fmt.Println("error al ver la probabilidad")
    }
	*/

	rand.Seed(time.Now().UnixNano())
	instructionsPerSwitch := 3	//args[1]

	go generarProcesos(procesos)

	go dispatcher(instructionsPerSwitch, probabilidad_bloqueo)
	go procesoExecution()

	time.Sleep(10 * time.Second)	
	fmt.Println("Simulación finalizada.")

	
}
