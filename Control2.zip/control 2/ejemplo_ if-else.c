#include <stdio.h>

// Este programa determina si un número es positivo o no. 
// Si el número es mayor que cero, imprime un mensaje indicando que es positivo. 
// De lo contrario, indica que es negativo o igual a cero.

int main() {
    int numero = 10; // Número que vamos a evaluar

    // Simulación de if-else
    if (numero > 0) {
        goto positivo; // Si el número es mayor a 0, salta a la etiqueta "positivo"
    }
    goto no_positivo; // Si no es mayor a 0, salta a la etiqueta "no_positivo"

positivo:
    printf("El número es positivo.\n"); // Mensaje si el número es positivo
    goto fin; // Salta al final del programa

no_positivo:
    printf("El número es negativo o cero.\n"); // Mensaje si el número no es positivo

fin:
    printf("Fin del programa.\n"); // Mensaje final
    return 0;
}

