#include <stdio.h>

// Este programa simula un menú de opciones utilizando `goto` e `if`. 
// Dependiendo de la opción seleccionada, se ejecuta un caso específico 
// o un mensaje indicando que la opción no es válida.

int main() {
    int opcion = 2; // Opción seleccionada por el usuario

    // Simulación de switch con if y goto
    if (opcion == 1) goto caso_1;
    if (opcion == 2) goto caso_2;
    goto caso_default; // Salta al caso por defecto si no es 1 ni 2

caso_1:
    printf("Opción 1 seleccionada.\n");
    goto fin; // Salta al final del programa

caso_2:
    printf("Opción 2 seleccionada.\n");
    goto fin; // Salta al final del programa

caso_default:
    printf("Opción no válida.\n");

fin:
    printf("Fin del programa.\n"); // Mensaje final
    return 0;
}
