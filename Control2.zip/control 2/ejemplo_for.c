#include <stdio.h>

// Este programa utiliza `goto` para simular un ciclo for. 
// Imprime los números del 0 al 4, incrementando uno en cada iteración.

int main() {
    int indice = 0; // Variable de control del ciclo

inicio:
    if (indice >= 5) goto fin; // Condición de salida: si indice >= 5, termina el ciclo
    printf("Índice = %d\n", indice); // Imprime el valor actual de la variable indice
    indice++; // Incrementa la variable indice
    goto inicio; // Vuelve al inicio del ciclo

fin:
    printf("Fin del ciclo for.\n"); // Mensaje final
    return 0;
}
