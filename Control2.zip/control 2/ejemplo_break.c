#include <stdio.h>

// Este programa utiliza `goto` para simular un ciclo con la instrucción break. 
// Imprime los números del 0 al 4 y detiene el ciclo cuando el contador llega a 3.

int main() {
    int contador = 0; // Variable de control del ciclo

inicio:
    if (contador >= 5) goto fin; // Condición de salida: si contador >= 5, termina el ciclo
    if (contador == 3) goto salir; // Simula break cuando contador == 3
    printf("Contador = %d\n", contador); // Imprime el valor actual del contador
    contador++; // Incrementa la variable contador
    goto inicio; // Vuelve al inicio del ciclo

salir:
    printf("El ciclo fue interrumpido.\n"); // Mensaje al interrumpir el ciclo

fin:
    printf("Fin del programa.\n"); // Mensaje final
    return 0;
}
