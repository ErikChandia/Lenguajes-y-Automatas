#include <stdio.h>

// Este programa utiliza `goto` para simular un ciclo do-while. 
// Imprime los números del 0 al 4, incrementando uno en cada iteración.

int main() {
    int contador = 0; // Variable de control del ciclo

inicio:
    printf("Contador = %d\n", contador); // Imprime el valor actual de la variable contador
    contador++; // Incrementa la variable contador
    if (contador < 5) goto inicio; // Si contador < 5, vuelve al inicio del ciclo

    printf("Fin del ciclo do-while.\n"); // Mensaje final
    return 0;
}
