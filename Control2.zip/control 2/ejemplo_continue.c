#include <stdio.h>

// Este programa utiliza `goto` para simular un ciclo con la instrucción continue. 
// Imprime los números impares del 0 al 9, saltando los números pares.

int main() {
    int contador = 0; // Variable de control del ciclo

inicio:
    if (contador >= 10) goto fin; // Condición de salida: si contador >= 10, termina el ciclo
    if (contador % 2 == 0) { // Si el contador es par, salta a la siguiente iteración
        contador++;
        goto inicio; // Simula la instrucción continue
    }
    printf("Contador = %d\n", contador); // Imprime el valor actual del contador (solo impares)
    contador++; // Incrementa la variable contador
    goto inicio; // Vuelve al inicio del ciclo

fin:
    printf("Fin del programa.\n"); // Mensaje final
    return 0;
}
