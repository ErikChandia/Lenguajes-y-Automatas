#include <stdio.h>

// Este programa evalúa si un número es positivo, negativo o cero. 
// Dependiendo del valor del número, imprime un mensaje correspondiente.

int main() {
    int numero = -5; // Número que vamos a evaluar

    // Simulación de if-else anidado
    if (numero > 0) {
        goto positivo; // Si el número es mayor a 0, salta a la etiqueta "positivo"
    }
    if (numero < 0) {
        goto negativo; // Si el número es menor a 0, salta a la etiqueta "negativo"
    }
    goto cero; // Si no es mayor ni menor a 0, salta a la etiqueta "cero"

positivo:
    printf("El número es positivo.\n"); // Mensaje si el número es positivo
    goto fin; // Salta al final del programa

negativo:
    printf("El número es negativo.\n"); // Mensaje si el número es negativo
    goto fin; // Salta al final del programa

cero:
    printf("El número es cero.\n"); // Mensaje si el número es igual a 0

fin:
    printf("Fin del programa.\n"); // Mensaje final
    return 0;
}
