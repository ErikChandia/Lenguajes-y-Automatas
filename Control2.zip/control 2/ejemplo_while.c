#include <stdio.h>

// Este programa utiliza `goto` para simular un ciclo while. 
// Imprime los números del 0 al 4, incrementando uno en cada iteración.

int main() {
    int contador = 0; // Variable de control del ciclo

inicio:
    if (contador >= 5) goto fin; // Condición de salida: si contador >= 5, termina el ciclo
    printf("Contador = %d\n", contador); // Imprime el valor actual de la variable contador
    contador++; // Incrementa la variable contador
    goto inicio; // Vuelve al inicio del ciclo

fin:
    printf("Fin del ciclo while.\n"); // Mensaje final
    return 0;
}
