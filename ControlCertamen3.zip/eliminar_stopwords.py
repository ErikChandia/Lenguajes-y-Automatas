import nltk
from nltk.corpus import stopwords

# Descargar las stopwords de NLTK
nltk.download('stopwords')

# Obtener las stopwords en inglés
stopwords_set = set(stopwords.words('english'))

# Leer el archivo de entrada con codificación UTF-8
with open("indice_invertido_1k.txt", "r", encoding="utf-8") as f:
    lines = f.readlines()

# Procesar las líneas y eliminar las stopwords
new_lines = []
for line in lines:
    # Ignorar líneas vacías
    if line.strip():
        # Intentar separar palabra y URLs
        parts = line.split(": ", 1)
        
        # Si no se pueden separar en 2 partes, se salta esta línea
        if len(parts) != 2:
            continue
        
        word, urls = parts  # Separar palabra y URLs
        words = word.split()  # Dividir la palabra clave en sus componentes (si tiene más de una palabra)
        
        # Filtrar las palabras que no son stopwords
        filtered_words = [w for w in words if w.lower() not in stopwords_set]
        
        # Si no hay palabras después de eliminar las stopwords, se ignora la línea
        if filtered_words:
            new_word = " ".join(filtered_words)  # Unir las palabras restantes
            new_lines.append(f"{new_word}: {urls}")

# Escribir el nuevo archivo sin stopwords
with open("indice_invertido_1k_sinstopword.txt", "w", encoding="utf-8") as f:
    f.writelines(new_lines)

print("El índice sin stopwords ha sido generado como 'indice_invertido_1k_sinstopword.txt'.")
