import sys

def cargar_indice(ruta_archivo):
    """
    Carga el índice invertido desde un archivo a un diccionario en memoria.
    """
    indice_invertido = {}
    with open(ruta_archivo, "r", encoding="utf-8") as archivo:
        for linea in archivo:
            if linea.strip():
                palabra, urls = linea.split(": ", 1)
                indice_invertido[palabra] = set(urls.strip().split(","))
    return indice_invertido

def buscar_recursivo(indice, palabras, resultado_actual=None):
    """
    Busca recursivamente las URLs asociadas a las palabras ingresadas.
    """
    if not palabras:  # Caso base: no hay más palabras
        return resultado_actual

    palabra_actual = palabras[0]
    if palabra_actual not in indice:
        return set()  # Si una palabra no está en el índice, no hay resultados

    urls_actuales = indice[palabra_actual]
    if resultado_actual is None:
        resultado_actual = urls_actuales
    else:
        resultado_actual = resultado_actual & urls_actuales  # Intersección

    return buscar_recursivo(indice, palabras[1:], resultado_actual)

def procesar_consultas(archivo_consultas, indice, archivo_salida):
    """
    Procesa un archivo de consultas y guarda los resultados en un archivo de salida.
    """
    with open(archivo_consultas, "r", encoding="utf-8") as consultas, \
         open(archivo_salida, "w", encoding="utf-8") as salida:
        for linea in consultas:
            palabras = linea.strip().split()
            resultado = buscar_recursivo(indice, palabras)

            salida.write(f"Consulta: {' '.join(palabras)}\n")
            if resultado:
                salida.write("Resultados:\n")
                for url in resultado:
                    salida.write(f"{url}\n")
            else:
                salida.write("No se encontraron resultados.\n")
            salida.write("\n")

def main():
    """
    Función principal para interactuar con el usuario o procesar un archivo de consultas.
    """
    ruta_archivo = "indice_invertido_1k_sinstopword.txt"
    print(f"Cargando índice invertido desde {ruta_archivo}...")
    indice_invertido = cargar_indice(ruta_archivo)
    print("Índice cargado exitosamente.")

    modo = input("Seleccione el modo: 'interactivo' o 'archivo': ").strip().lower()

    if modo == "interactivo":
        print("\nBuscador interactivo. Escribe palabras separadas por espacios para buscar.")
        print("Escribe 'salir' para terminar el programa.\n")

        while True:
            consulta = input("> ").strip()
            if consulta.lower() == "salir":
                print("Saliendo del programa.")
                break

            palabras = consulta.split()
            # Verificar que todas las palabras estén en el índice
            palabras_validas = [p for p in palabras if p in indice_invertido]
            if not palabras_validas:
                print("No se encontraron resultados para la consulta.")
                continue

            resultado = buscar_recursivo(indice_invertido, palabras_validas)

            if resultado:
                print("Resultados encontrados:")
                for url in resultado:
                    print(url)
            else:
                print("No se encontraron resultados para la consulta.")

    elif modo == "archivo":
        archivo_consultas = input("Ingrese el nombre del archivo de consultas: ").strip()
        archivo_salida = input("Ingrese el nombre del archivo de salida: ").strip()

        print(f"Procesando consultas desde {archivo_consultas} y guardando resultados en {archivo_salida}...")
        procesar_consultas(archivo_consultas, indice_invertido, archivo_salida)
        print("Procesamiento completado.")

if __name__ == "__main__":
    main()
